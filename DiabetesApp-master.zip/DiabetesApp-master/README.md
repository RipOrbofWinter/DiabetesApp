# DiabetesApp
Official fontys groep 3 app 

Gun example docs:
https://gun.eco/docs/Todo-Dapp

ASP tutorial:
https://www.youtube.com/watch?v=4IgC2Q5-yDE&list=PL6n9fhu94yhVkdrusLaQsfERmL_Jh4XmU

JS Unit testing:
https://designmodo.com/test-javascript-unit/  
JS Unit testing video: 
https://www.youtube.com/watch?v=r9HdJ8P6GQI

jQuery Tutorial:
https://www.youtube.com/watch?v=hMxGhHNOkCU
 
